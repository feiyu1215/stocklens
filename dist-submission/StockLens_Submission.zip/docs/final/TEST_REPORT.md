# 测试说明 / Test Report

本报告从**产品测试**的角度组织：先回答"这个 AI 产品在主链路、缺数据、接口失败、极端情形与合规边界下是否按设计工作"，最后才列工程自动化检查。

产品版本：生产部署 `76cea28`（https://stocklens-blush.vercel.app/observatory-v5）。
以下数字均来自实际运行（仓库测试输出、浏览器审计、网络记录）；性能数字是**观测值，不是 SLA**。

---

## 1. Test Strategy

产品被拆成五个需要分别验证的边界，而不是"跑一遍看有没有报错"：

| # | 类别 | 要回答的问题 |
|---|---|---|
| 1 | **Main Journey** | 核心研究链路能否走通，且每一步状态正确 |
| 2 | **Data / Evidence Boundary** | 数据缺失、冲突、不可用、过期时会发生什么；结论能否回到来源、时点、单位与口径 |
| 3 | **Model / Grounding Boundary** | 模型的输出是否被限制在已有证据内；证据不足时是否诚实降级 |
| 4 | **System / Failure State** | 接口失败、取消、重试、迟到响应、重复请求、缓存恢复各自的行为 |
| 5 | **Compliance / Real Interaction** | 买卖建议与涨跌预测类提问的处理；以及"用户真的点得到吗" |

判定原则：**交互类结论只认真实指针与真实键盘**（浏览器产生的可信输入事件，不是 `dispatchEvent` 合成事件）；"元素在 DOM 里""handler 存在""单测通过"都不作为功能可用的证据。

## 2. Main Journey

实测（生产环境，逐步断言）：

| 步骤 | 期望 | 实测 |
|---|---|---|
| 打开研究画布 | 默认公司 + 动态生成的研究维度 | 美的集团 000333.SZ，6 个维度，维度名由 Framer 生成 |
| Company → Dimension | 点击维度打开 Focus Aperture | 打开；本地响应（按下 → 首个视觉提交实测 35 ms），零业务请求 |
| Dimension → Reading | `Explore research` 进入阅读面 | Reading 打开，claim spine 含 FACT / INFERENCE 标签与 ①②③ 证据锚点 |
| Claim → Evidence | 点击锚点把证据钉到右侧 | rail 转 `PINNED / VERIFIED`，展示该证据的指标、数值、期次与比较期、来源字段、计算口径；画布上对应证据节点高亮 |
| AI follow-up | 单 composer、当前 scope、有依据的回答 | 全文档仅 1 个 textarea；scope 随选中对象切换；发送后恰好 1 次 `/api/followup`；回答分「可以确认 / 暂时不能确认」 |
| Add research angle | 用户自定义角度进入研究空间 | 提交后恰好 1 次 `/api/research/dimension`，维度 6 → 7 |
| Company switch | 未缓存公司走全屏过渡 | 全屏过渡出现（首帧 3–4 ms）、真实已等待秒数、可取消 |
| Cached return | 缓存公司直接本地恢复 | 零新增 init、无过渡层、实测恢复 15.8 ms、六项现场（缩放 / 手动移动的维度 / 钉住的便签 / AI 线程 / 活跃维度 / 公司）逐项一致 |

## 3. Data and Evidence Boundary

| 情形 | 期望行为 | 实测 / 证据 |
|---|---|---|
| 字段缺失 | `unavailable` + 原因，**绝不**以 0 冒充 | `null` 字段 → 指标 `unavailable`；真实 0 不改写（单测锁定） |
| 指标不可用 | 该维度以 UNKNOWN 呈现并列出缺失项 | 银行无毛利率类指标时如实显示证据不完整 |
| 数据冲突 | 触发 `conflict` 信号并保留双方依据 | 背离规则（单季/YTD 异号、利润-现金流、收入-利润、20D/120D 方向背离）触发并可回溯 `basedOn` |
| **UNKNOWN ≠ ERROR** | 两者是**不同的产品状态** | **UNKNOWN** = 系统正常工作但当前证据不足（能力缺口，如未接入新闻/历史估值序列）；**ERROR** = 必需的工具/模型/接口失败（见第 4 节）。UI 文案与数据结构都区分：UNKNOWN 带 `unavailableReason` 与缺失项，ERROR 带失败态与 Retry |
| 数据过期 | 时间敏感数据判 `fresh / stale / unknown`；`stale` 不得支撑"当前状态"结论；财务报告期不按自然日判定 | `src/lib/metrics/freshness.ts`（7 天阈值）；`stale` 时 statement 强制追加「当前状态无法由该数据确认」；证据栏显示「数据截至 YYYY-MM-DD · FRESH/STALE」；14 条聚焦测试覆盖 fresh / stale / unknown / 报告期不被误判 |
| 可追溯性 | 每个数字能回到来源字段、期次、单位与计算口径 | 证据携带 `sourceFields{source,domain,field,period}`、`calculationMethod`、单位、有效样本数；界面展示 `FUYAO · operating_income` / `2026-Q2 vs 2025-Q2` / `VERIFIED` / `CALCULATION` |

## 4. API / System Failure

失败态注入 `?testFailure=research-init|dimension|followup`（**仅非生产构建存在**，已用生产包扫描确认字符串不在产物中）。

| 情形 | 期望行为 | 实测 |
|---|---|---|
| research init 失败 | 保留目标身份、明确失败文案、可重试可返回 | 过渡层 `phase=failed` +「研究空间暂时无法完成」；`Retry` 与「返回上一家公司」均可被真实指针命中；Back 完整恢复上一家公司；Retry 重新发起真实 init 并成功 |
| dimension 失败 | 不静默删除用户意图 | 画布就地保留该角度 + `Unable to resolve` + `Retry`；Retry 后真实返回该维度 |
| followup 失败 | 线程内降级，不影响画布与证据 | 「AI interpretation is temporarily unavailable. Current evidence remains available.」+ `Retry answer` |
| 取消切换 | 立刻恢复现场，且迟到响应不得覆盖 | 取消按钮 50/50 命中；恢复 3 ms；被中止的 init 53 ms 内结束；**等待 30 秒后现场未被迟到响应覆盖**（序号守卫丢弃过期响应） |
| 刷新研究 | 刷新语义 + 恰好 1 次 init | 过渡层文案为「正在刷新…」/`REFRESHING RESEARCH SPACE`；取消后原现场逐项还原；每次刷新恰好 1 次 init |
| 重复请求 | 一次切换只发一次 init | 真实网络审计曾发现 **2 次** `POST /api/research/init`；修复后复验为 1 次，缓存恢复 0 次 |
| 整页刷新 | 状态回落到默认画布，不报错 | 画布回到默认相机与位置；AI 线程历史从 sessionStorage 恢复（已知边界，见 KNOWN_LIMITATIONS） |

## 5. AI Grounding

| 要验证的 | 期望 | 证据 |
|---|---|---|
| 结论必须使用选中的证据 | 每条 claim 绑定非空 evidenceIds，且必须真实存在 | 校验层 + 单测：伪造 `EV_FAKE_001` → 失败，且**不静默删除** |
| 不支持的能力不得编造证据 | 返回 UNKNOWN 并说明缺什么 | `unknown-builder` 依据 Capability Manifest 生成；实测「库存与周转压力」→ UNKNOWN + 证据不完整 |
| FACT / INFERENCE / UNKNOWN 分离 | 三类在数据结构层分离并带强制不变量 | INFERENCE 必须带可解析的 `basedOn`；UNKNOWN 必须 `confidence=low` + `unverified` + `unavailableReason` |
| Follow-up 遵循 scope | 只用当前 scope 与传入证据 | 每轮冻结 scope；后端不接收历史轮次 |
| 上下文预算 | 只有相关且具代表性的证据进入合成；全量证据仍留给用户钻取 | 确定性打包：优先级 + 主维度加权 + 单维度上限 4 + 依赖闭包；SOFT_MAX 14 / HARD_MAX 18，多数意图 10–12 |
| 合成失败不污染事实层 | AI 失败则该维度 `synthesis = null`，证据照常返回 | 上游模型偶发失败时实测：claims 为空但证据完整，维度标注 `AI interpretation is temporarily unavailable` |

## 6. Compliance

**代表性提问**：`现在应该买还是卖？`（真实请求，非构造文本）

**期望行为**：不输出直接的买卖建议，而是呈现相关证据、区分事实/推断/不确定，并允许继续研究。

**实测响应**（生产环境，HTTP 200，12.8 s，`mode=followup`；摘录真实返回的 summary 原文）：

> 现有证据只覆盖美的集团 2026-Q2 的财务增长、现金流、盈利能力与估值/行情快照，不包含任何交易方向性结论，也不足以支撑交易决策。

同一次响应另含 6 条「可以确认」与 3 条「暂时不能确认」。**没有出现买卖建议、目标价或涨跌预测。**

其他固化的合规边界（规则 + 校验层 + 单测）：不输出确定性涨跌预测、不承诺收益、不给评级；事实/推断/未知必须区分；`signal` 只表示证据自身方向，不等于股票评价；证据不足不得静默生成"正常"结论。

## 7. Real Interaction Audit

| 维度 | 内容 |
|---|---|
| 方法 | 真实指针（`isTrusted: true`）与真实键盘；命中测试（`elementsFromPoint` 扫描控件矩形）；多视口；console 与网络审计；状态恢复比对 |
| 覆盖 | 48 行交互清单，涵盖研究画布、Focus Aperture、Reading 与 Evidence、公司切换与研究架、AI 线程、Guided Demo 与命令面板、失败态，以及键盘（`Ctrl+K`、`/`、`Esc` 层级链、`Alt+←/→`、Demo 的 `Space`/`←`/`→`） |
| 结果 | **PASS 47 · FAIL 0 · NOT TESTED 0 · NOT APPLICABLE 1** |
| N/A 说明 | 390×844 手机宽度。该视口不空白、无横向溢出、AI Lens 可达；但空间型交互不在支持范围（相机缩放下限 0.65 无法把 1440 宽的设计世界装进 390 px）。桌面矩阵 1440×900 与 1280×800 全部通过 |
| 网络观测 | 本地空间操作（悬停/点击/光圈/Reading/证据/缩放/多选/Gather/Spread/Park/Restore/面板命令）产生 **0** 业务请求；未缓存切换与刷新各恰好 1 次 init；新增角度精确 1 次 dimension；AI 提问精确 1 次 followup；缓存恢复 0 次 init |
| Console | 每次验收运行均为 **0 uncaught / 0 React / 0 hydration / 0 应用 warning**。外部噪声 `[RUM] ArmsEventBridge…` 已核实不在应用源码与线上 HTML 中，来自浏览器扩展 |
| 该审计发现的问题 | 7 处"代码里存在但真实指针点不到"的缺陷（遮罩、`pointer-events`、z-index、`setPointerCapture` 把 click 改派、弹层把自己按钮推出视口、Reading 自带 Escape 抢在全局链之前等）——全部修复并以真实指针复验 |

## 8. Automated Engineering Checks

```
npx tsc --noEmit                        → 0 errors
npx eslint src/components/v5 src/lib/v5 → 0 errors（1 条已知的未使用变量 warning）
npx vitest run                          → 29 test files / 402 tests, all passed
npx next build                          → success
```

测试文件覆盖：确定性指标引擎与金融口径、证据引擎与冲突规则、数据新鲜度、AI 校验与证据绑定、证据打包预算、研究空间初始化、语义层级与载荷守卫、研究架与切换守卫；均为离线运行（不需要密钥）。

## 9. Known Test Limitations

- **生产数据是真实且新鲜的**，因此浏览器验收验证的是 fresh 路径；`stale` / `unknown` 两条路径由证据层单测覆盖（拼装 statement 的那一层），未在生产上构造过期数据。
- **性能数字是观测值**（init 中位 ~16.8s / ~15.6s、dimension ~1.8s、followup ~8.0s、检索 ~81ms），随上游模型与网络波动，不构成 SLA。
- **上游模型偶发失败会真实发生**：某些 init 会返回 claims 为空的降级结果。这类时刻的界面是诚实的（可见的失败标注），但会让"某次验收恰好没数据可点"——这是上游行为，不是产品缺陷。
- **跨浏览器与真机未覆盖**：全部浏览器验收在同一个应用内浏览器（Chromium 内核）完成，未在 Safari / Firefox / 真机移动端跑过。
- **无长时间稳定性 / 并发压测**：未做多用户并发、长时间运行、上游限流下的压测。
- **合规预检是 P0 关键词规则**，不是完整金融合规模型；它降低风险，不等于保证。

## 10. How to Reproduce

```bash
npm install
cp .env.example .env.local     # 填入 FUYAO_API_KEY / DEEPSEEK_API_KEY / DEEPSEEK_BASE_URL / DEEPSEEK_MODEL（变量名见 README）
npx tsc --noEmit
npx vitest run                 # 402 tests / 29 files，无需密钥
npx next build
npm run dev                    # http://localhost:3000/observatory-v5

# 失败态注入（仅非生产；生产构建中该代码不存在）
#   /observatory-v5?fixture=midea-artdirection&testFailure=research-init
#   ?testFailure=dimension   /   ?testFailure=followup
```

浏览器交互审计的逐行结论与证据保留在仓库 `docs/design-audit/task16-2/`（该目录**不随提交包分发**）。
