import "server-only"

import { randomUUID } from "node:crypto"

import { loadTruthForResearch } from "@/lib/research/init-space"
import type { Evidence } from "@/lib/evidence/types"
import { LLMConfigError, parseLLMJson, runLLM } from "./model"
import {
  FOLLOWUP_PROMPT_VERSION,
  buildFollowupRepairPrompt,
  buildFollowupSystemPrompt,
  buildFollowupUserPrompt,
} from "./prompts/followup"
import { validateDiagnosisSynthesis } from "@/lib/validation/diagnosis"
import type { AIInvocationTrace, DiagnosisSynthesis } from "./types"

// Followup Runner（Task 06）：诊断后沿证据继续研究的追问链路。
// 复用 Truth Layer 与 DiagnosisSynthesis schema / Validator；
// 每次调用重新执行 Truth Layer（无持久化），保证证据始终是当次真实数据。

const FOLLOWUP_TEMPERATURE = 0.2
// 1800 是旧世代模型的预算；2026-09 DeepSeek 换代后（chat 别名指向推理型 Flash），
// 推理 token 会挤占输出预算导致 JSON 截断，放宽到 4000
const FOLLOWUP_MAX_TOKENS = 4000
const DEFAULT_FOLLOWUP_BUDGET_MS = 55_000
const MIN_LLM_CALL_MS = 1_000

export interface FollowupResult {
  followupId: string
  mode: "followup" | "compliance_redirect"
  compliance?: { message: string; suggestedQuestions: string[] }
  question: string
  /** 客户端焦点证据中真实存在的那部分（伪造 ID 被过滤，不进入 grounding 声明） */
  focusEvidenceIds: string[]
  /** 客户端提交但不存在于证据集的 ID（用于 UI 提示，静默过滤会掩盖问题） */
  ignoredEvidenceIds: string[]
  synthesis: DiagnosisSynthesis | null
  evidence: Evidence[]
  ai: { status: "success" | "failed"; trace?: AIInvocationTrace }
}

function failedTrace(trace: AIInvocationTrace, issues: string[]): AIInvocationTrace {
  return { ...trace, status: "failed", validationIssues: issues }
}

export async function runFollowup(input: {
  stockCode: string
  question: string
  focusEvidenceIds?: string[]
  /** 路由级绝对截止时间；为响应序列化与平台开销预留余量。 */
  deadlineAt?: number
}): Promise<FollowupResult> {
  const followupId = randomUUID()
  const deadlineAt = input.deadlineAt ?? Date.now() + DEFAULT_FOLLOWUP_BUDGET_MS
  const { truth } = await loadTruthForResearch(input.stockCode)
  const { dataResp, metrics: metricsResp } = truth
  const bundle = { evidence: truth.evidence }

  const llmTimeoutMs = () => Math.min(20_000, Math.max(0, deadlineAt - Date.now()))
  const budgetFailure = (base: Omit<FollowupResult, "mode" | "synthesis" | "ai">): FollowupResult => ({
    ...base,
    mode: "followup",
    synthesis: null,
    ai: {
      status: "failed",
      trace: {
        task: "diagnosis_synthesis",
        model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
        promptVersion: FOLLOWUP_PROMPT_VERSION,
        status: "failed",
        latencyMs: 0,
        retries: 0,
        validationIssues: ["追问处理已达到本次请求的总耗时预算"],
      },
    },
  })

  const requested = input.focusEvidenceIds ?? []
  const focusEvidenceIds = requested.filter((id) => bundle.evidence.some((e) => e.evidenceId === id))
  const ignoredEvidenceIds = requested.filter((id) => !focusEvidenceIds.includes(id))

  const base = {
    followupId,
    question: input.question,
    focusEvidenceIds,
    ignoredEvidenceIds,
    evidence: bundle.evidence,
  }

  // 焦点证据为空：没有可锚定的追问上下文，直接以失败返回（不编造）
  if (focusEvidenceIds.length === 0) {
    return {
      ...base,
      mode: "followup",
      synthesis: null,
      ai: { status: "failed" },
    }
  }

  if (llmTimeoutMs() < MIN_LLM_CALL_MS) return budgetFailure(base)

  let first: Awaited<ReturnType<typeof runLLM>>
  try {
    first = await runLLM({
      task: "diagnosis_synthesis",
      promptVersion: FOLLOWUP_PROMPT_VERSION,
      systemPrompt: buildFollowupSystemPrompt(),
      userPrompt: buildFollowupUserPrompt({
        question: input.question,
        stock: { stockCode: input.stockCode, stockName: dataResp.stock?.stockName ?? input.stockCode },
        context: {
          latestFinancialPeriod: metricsResp.latestFinancialPeriod,
          latestTradeDate: metricsResp.latestPriceDate,
        },
        focusEvidenceIds,
        evidence: bundle.evidence,
      }),
      temperature: FOLLOWUP_TEMPERATURE,
      maxTokens: FOLLOWUP_MAX_TOKENS,
      timeoutMs: llmTimeoutMs(),
      networkRetries: 0,
    })
  } catch (err) {
    return {
      ...base,
      mode: "followup",
      synthesis: null,
      ai: {
        status: "failed",
        trace: {
          task: "diagnosis_synthesis",
          model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
          promptVersion: FOLLOWUP_PROMPT_VERSION,
          status: "failed",
          latencyMs: 0,
          retries: 0,
          validationIssues: [err instanceof LLMConfigError ? err.message : String(err)],
        },
      },
    }
  }

  const attemptValidation = (output: string) => {
    try {
      return validateDiagnosisSynthesis(parseLLMJson(output), bundle.evidence)
    } catch (err) {
      return {
        ok: false as const,
        issues: [{ section: "parse", rule: "invalid-json", message: err instanceof Error ? err.message : String(err) }],
      }
    }
  }

  if (first.trace.status === "failed") {
    return {
      ...base,
      mode: "followup",
      synthesis: null,
      ai: { status: "failed", trace: failedTrace(first.trace, first.trace.validationIssues ?? []) },
    }
  }

  const firstValidation = attemptValidation(first.output)
  if (firstValidation.ok) {
    return { ...base, mode: "followup", synthesis: firstValidation.synthesis, ai: { status: "success", trace: first.trace } }
  }

  // 修复重试：最多 2 轮，每轮回喂上一轮输出与累计问题。
  // 2026-09 模型世代切换后（chat 别名指向推理型 Flash），首轮分区纪律的偶发违规率上升，
  // 单轮修复不稳；证据纪律本身不让步——重试仍不通过才判 failed。
  const issues = [...firstValidation.issues]
  let lastOutput = first.output
  let lastTrace = first.trace
  for (let repairRound = 1; repairRound <= 2; repairRound++) {
    if (llmTimeoutMs() < MIN_LLM_CALL_MS) return budgetFailure(base)
    const repaired = await runLLM({
      task: "diagnosis_synthesis",
      promptVersion: FOLLOWUP_PROMPT_VERSION,
      systemPrompt: buildFollowupSystemPrompt(),
      userPrompt: buildFollowupRepairPrompt(
        lastOutput,
        issues.map((i) => `${i.section}/${i.rule}: ${i.message}`),
      ),
      temperature: FOLLOWUP_TEMPERATURE,
      maxTokens: FOLLOWUP_MAX_TOKENS,
      timeoutMs: llmTimeoutMs(),
      networkRetries: 0,
    })

    if (repaired.trace.status === "failed") {
      issues.push(...(repaired.trace.validationIssues ?? []).map((m) => ({ section: "llm", rule: "request-failed", message: m })))
      return {
        ...base,
        mode: "followup",
        synthesis: null,
        ai: { status: "failed", trace: failedTrace(repaired.trace, issues.map((i) => `${i.section}/${i.rule}: ${i.message}`)) },
      }
    }
    const validation = attemptValidation(repaired.output)
    if (validation.ok) {
      return {
        ...base,
        mode: "followup",
        synthesis: validation.synthesis,
        ai: {
          status: "success",
          trace: {
            ...repaired.trace,
            retries: repaired.trace.retries + repairRound,
            validationIssues: issues.map((i) => `${i.section}/${i.rule}: ${i.message}`),
          },
        },
      }
    }
    issues.push(...validation.issues)
    lastOutput = repaired.output
    lastTrace = repaired.trace
  }
  return {
    ...base,
    mode: "followup",
    synthesis: null,
    ai: { status: "failed", trace: failedTrace(lastTrace, issues.map((i) => `${i.section}/${i.rule}: ${i.message}`)) },
  }
}
