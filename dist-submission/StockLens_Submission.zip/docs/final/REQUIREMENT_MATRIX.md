# Requirement Matrix

对照原始作业 `03_个股多维诊断与证据验证.md` 逐条给出实现、证据与状态。

状态口径：**PASS** = 有可复现的实现与证据；**PARTIAL** = 已实现但存在明确缺口（缺口写在行内）；**NOT DELIVERED** = 未交付（仅用于可选项）。不夸大：没有做的能力一律写明"未接入"。

产品版本：生产部署 `db618d4`。

---

## 题目内容

| # | Original Requirement | StockLens Implementation | Evidence | Status |
|---|---|---|---|---|
| 1 | 选择一只 A 股，设计并实现一个 AI Native 个股诊断产品 | 默认研究标的美的集团 000333.SZ；可搜索并切换任意 A 股（`GET /api/stocks/search`）。产品是研究画布而非问答页：空间探索 + 自然语言两条平行通道 | 生产 URL `/observatory-v5`；`docs/final/screenshots/01-research-canvas.png` | PASS |
| 2 | 帮助用户从经营质量、财务趋势、估值、行情特征、行业位置、重要事件与风险等维度理解公司当前状态 | 研究维度由 Research Framer 动态命名，覆盖这些域：实测美的得到「盈利质量 / 增长韧性 / 现金转化能力 / 估值相对位置 / 市场与行业相对表现 / 股东回报与公司行为」；招商银行得到「盈利质量与资本回报 / 资产质量与风险抵补 / 估值安全边际与行业相对 / 市场相对表现与波动 / 股东回报与分红可持续性」 | `docs/final/screenshots/01-research-canvas.png`、`06-company-switch.png`；Framer 实现在 `src/lib/research/framer.ts` | PASS |
| 3 | 区分客观事实、分析推断与暂时无法验证的信息 | 证据对象自带 `type: fact \| inference \| unknown` 与强制不变量（unknown 必须 `confidence=low` + `verifyStatus=unverified` + 带 `unavailableReason`）；UI 分区呈现，Reading 的 claim 明确标注 FACT / INFERENCE | `src/lib/evidence/types.ts`、`src/lib/evidence/validate.ts`；`docs/final/screenshots/03-claim-evidence.png`（可见 `FACT POSITIVE` / `INFERENCE` 标签） | PASS |
| 4 | 支持用户沿证据继续研究 | 每条 claim 带 ①②③ 证据锚点 → 点击把该证据钉到右侧 Evidence Rail（含指标、数值、期次、来源、计算口径）；底部 AI Research Lens 可在当前 scope 追问；画布上对应证据节点同步高亮 | `docs/final/screenshots/03-claim-evidence.png`、`04-ai-research-lens.png`；实测：点 ① 与 ② 分别钉住不同证据并把对应节点置为高亮 | PASS |
| 5 | 不给出简单"好/坏"标签或买卖建议 | 无评分、无评级、无好坏标签；证据引擎契约禁止 signal 之外的 score/rating 字段；合规预检 + 输出扫描 + 校验三层拦截 | `src/lib/metrics/types.ts`（禁止 score 字段）、`src/lib/validation/diagnosis.ts`；`docs/final/TEST_REPORT.md` §9 | PASS |

## 提交要求

| # | Original Requirement | StockLens Implementation | Evidence | Status |
|---|---|---|---|---|
| 6 | 可运行主链路：**根据公司类型和用户问题选择诊断维度** | Research Framer 的输入 = 公司身份 + 行业（本地行业注册表，5572 只标的）+ 由真实指标推导的 Capability Manifest + 用户问题；维度 label 由模型自由命名，prompt 明令禁止套用同一组标签 | 跨公司差异实测（制造业 vs 银行，见 #2）；`src/lib/research/framer.ts`、`src/lib/research/capability.ts` | PASS |
| 7 | 体现**确定性指标计算、数据证据与 LLM 解读**的合理分工 | 三层分离：Truth Layer（扶摇取数 + 指标引擎 + 证据引擎，LLM 禁入）→ Intelligence Layer（Framer / Composer / Follow-up，只能引用已有 Evidence ID）→ Experience Layer（只呈现与钻取） | `src/lib/metrics/`（全部计算）、`src/lib/evidence/`、`src/lib/ai/`；`docs/final/ARCHITECTURE.md` | PASS |
| 8 | 正面、负面、矛盾和未知证据的**结构化表达** | `signal: positive \| negative \| conflict \| neutral \| unknown` 是证据对象的一等字段；背离类冲突由确定性规则触发（单季/YTD 异号、利润-现金流背离、收入-利润背离、20D/120D 方向背离等） | `src/lib/evidence/rules.ts`；实测可见 `6 evidence · 1 conflict` 徽标；单测 `tests/evidence/rules.test.ts` | PASS |
| 9 | 支持从诊断结论钻取到**财务期次、行情区间、同行对比或待验证问题** | 财务期次：每条指标的 period / comparisonPeriod（如 `2026-Q2 vs 2025-Q2`），单季与累计口径严格分离；行情区间：20/60/120 交易日收益、20/60 日年化波动、120 日最大回撤；**同行对比：行业级**（个股 PE/PB 与行业成分股中位数之差，含有效样本数）与行业指数相对表现；待验证问题：UNKNOWN 是正式结果，直接列出缺失数据项 | `docs/final/screenshots/03-claim-evidence.png`（期次与口径可见）；`src/lib/metrics/market.ts`、`market-context.ts`；**未做**：逐家成分股的财务报表级对标 | **PARTIAL**（同行比较只做到行业级，不是成分股级财务对标） |
| 10 | 提交可访问、可实际操作的 Web 产品 URL | https://stocklens-blush.vercel.app/observatory-v5 | 最终 smoke：页面加载、维度打开、Reading、Evidence、AI Lens、公司切换器全部可用（见 `docs/final/TEST_REPORT.md`） | PASS |
| 11 | 源代码仓库及 README | https://github.com/feiyu1215/stocklens ；README 覆盖启动方式、环境变量、产品选择、AI 的角色、数据来源、已知边界与未做事项 | 仓库 README.md；`docs/final/screenshots/` 为最终构建实拍 | PASS |
| 12 | **AI 使用与验证记录**：使用了哪些 AI 工具、AI 参与哪些环节、候选人修正了哪些错误或不合理结果 | 见 `docs/final/AI_USAGE_AND_VALIDATION.md`：区分"用于构建的 AI"与"产品内的 AI"，并列出 10 组候选人否决/纠正 AI 输出的真实记录 | `docs/final/AI_USAGE_AND_VALIDATION.md` §3 | PASS |
| 13 | **测试说明**：至少覆盖主链路、数据缺失/接口失败、极端或合规边界场景 | `docs/final/TEST_REPORT.md`：10 节，含 385 个自动化测试、主链路逐步实测、8 类失败/极端情形、48 行交互审计、网络与 console 审计、性能实测、合规边界 | `docs/final/TEST_REPORT.md` | PASS |
| 14 | 关键数字与结论必须**可追溯** | 指标级：`sourceFields{source,domain,field,period}` + `calculationMethod` + 单位 + 有效样本数；证据级：`period / comparisonPeriod / metricIds / ruleId / basedOn`（推断可回溯到事实）；界面 Evidence Rail 直接展示这些字段 | `docs/final/screenshots/03-claim-evidence.png`（`FUYAO · operating_income` / `2026-Q2` / `VERIFIED` / `CALCULATION`）；`src/lib/metrics/types.ts` | PASS |

## 统一规则

| # | Original Requirement | StockLens Implementation | Evidence | Status |
|---|---|---|---|---|
| 15 | 不得在公开仓库提交 API Key、用户隐私或受限数据 | 密钥只存本地 `.env.local` 与部署平台环境变量；仓库仅含 `.env.example`（只有变量名）；提交包在打包时执行密钥扫描（密钥、Bearer token、.env 内容、Vercel/Fuyao/LLM 凭据、个人信息） | 打包脚本的扫描结果写入 `docs/final/PACKAGE_MANIFEST.md` | PASS |
| 16 | 产品不得输出确定性涨跌预测、收益承诺或直接买卖建议 | 合规预检 + Prompt 禁令 + 输出校验；模型被禁止给出评级与建议 | `src/lib/validation/diagnosis.ts`、`docs/final/TEST_REPORT.md` §9 | PASS |
| 17 | **事实、推断与不确定信息必须区分** | 数据结构层面分离（`type` 字段与强制不变量），UI 分区呈现；未知不是异常而是正式结果 | 同 #3；单测 `tests/evidence/engine.test.ts`「全部指标不可用 → 全部为 UNKNOWN，无 FACT/INFERENCE」 | PASS |
| 18 | 核心结论必须能回到**原始字段或原文**，并明确来源、时点、单位及统计口径 | 每条证据携带来源（FUYAO · 字段名）、时点（period / comparisonPeriod）、单位（`formatMetricValue` 与 metric 定义）、统计口径（`calculationMethod`，如单季还原公式） | `docs/final/screenshots/03-claim-evidence.png`；`docs/metric-catalog.md` 登记全部指标口径 | PASS |
| 19 | 数据**缺失、冲突、过期或调用失败**时不得静默生成"正常"结论 | 缺失 → `unavailable` + reason（绝不以 0 冒充）；冲突 → conflict 信号 + 背离规则；AI 调用失败 → 局部降级且界面可见；**过期**：数据日期以 period/date 展示，但**没有**新鲜度/时效守卫（若上游返回跨度过大的旧数据，系统不会主动降级或提示） | 单测 `tests/metrics/financial.test.ts`「字段为 null → unavailable，不是 0」、`tests/research-init.test.ts`「Composer 失败 → 维度仍在、claims 为空、ai=partial_failure」；`grep -r "stale\|freshness" src/lib` 无命中 | **PARTIAL**（过期数据缺少机制性防护） |
| 20 | 可选：提交 60–180 秒演示视频 | **未随包提供**。本环境无法产出稳定且合规的 MP4（环境内无视频编码器；应用内浏览器长流程录制不稳定）。改为提供录制脚本与六张最终截图；`docs/final/DEMO_SCRIPT.md` 可在任意具备录屏能力的环境一次录成 | `docs/final/DEMO_SCRIPT.md`、`docs/final/PRODUCT_WALKTHROUGH.md` | **NOT DELIVERED**（可选项） |

## 汇总

**PASS 18 · PARTIAL 1 · NOT DELIVERED 1（可选项）· 合计 20 行**

两个未满分项都不是隐藏问题，而是明确写出的边界：

1. **同行对比 = 行业级**（#9）：已实现行业估值中位数比较与行业指数相对表现；**不做**逐家成分股的财务报表级对标。README 与 KNOWN_LIMITATIONS 使用同一措辞。
2. **过期数据无机制性防护**（#19）：缺失/冲突/调用失败三种情形都有确定行为并有单测；"数据过期"目前只靠展示期次让用户自行判断，没有新鲜度守卫。

## 不在作业要求内、但本项目额外要求的（不参与上面的计数）

以下为候选人自设的工程/交付约束，不是作业原文要求，列出以免被误读为"要求已完成"：

- 提交包 ZIP < 30 MB（**平台约束**，由候选人提供）；
- 生产环境不得让普通用户触发失败态（因此 `?testFailure=` 注入只在非生产构建存在）；
- 浏览器验收必须以真实指针/键盘事件为准（禁用合成 `dispatchEvent` 作为通过证据）。
